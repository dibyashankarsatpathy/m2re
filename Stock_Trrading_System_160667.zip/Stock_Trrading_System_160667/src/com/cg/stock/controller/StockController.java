package com.cg.stock.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.stock.dto.Client;
import com.cg.stock.service.StockService;

@Controller
public class StockController
{
	@Autowired
	StockService ser;
	@RequestMapping("goto")
	public String getAll(Model model)
	{
		
		List<Client> list = ser.getAllData();
		model.addAttribute("list",list);
		
		return "index";
	}
	
	@RequestMapping("setOrder")
	public String setOrder(@RequestParam("stockid") int stc,Model model)
	{
		Client cobj= ser.getStock(stc);
		model.addAttribute("data",cobj);
		return "order";
	}
	
	@RequestMapping("placeOrder")
	public String placeOrder(@ModelAttribute("data") Client client, 
			@RequestParam("qty") int qty,Model model)
	{
		double totalCost=client.getQuote()*qty;
		model.addAttribute("cost",totalCost);
		model.addAttribute("stock",client.getStock());
		return "summary";
	}
	
	
	
}
