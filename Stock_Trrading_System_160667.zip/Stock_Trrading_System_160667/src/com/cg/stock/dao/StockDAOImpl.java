package com.cg.stock.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.stock.dto.Client;

@Repository("daoObj")
public class StockDAOImpl  implements StockDAO
{
	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public List<Client> getAllData() {
		
		String str="select stock from Client stock";
		TypedQuery<Client> queryOne=(TypedQuery<Client>) entitymanager.createQuery(str,Client.class);
		List<Client> myList=queryOne.getResultList();
		return myList;
		
	}

	@Override
	public Client getStock(int id) {
		
		Client obj= entitymanager.find(Client.class,id);
	
		return obj;
	}

}
